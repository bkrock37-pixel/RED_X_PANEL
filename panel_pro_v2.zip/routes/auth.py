
from flask import Blueprint,request,current_app
auth_bp=Blueprint("auth",__name__)

@auth_bp.route("/register",methods=["POST"])
def register():
    data=request.json
    current_app.db.users.insert_one(data)
    return {"status":"registered"}

@auth_bp.route("/login",methods=["POST"])
def login():
    data=request.json
    u=current_app.db.users.find_one(data)
    return {"login": bool(u)}
