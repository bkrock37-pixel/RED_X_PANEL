
from flask import Flask
from pymongo import MongoClient
from routes.auth import auth_bp

app=Flask(__name__)
app.config["MONGO_URI"]="YOUR_MONGODB_URI_HERE"
client=MongoClient(app.config["MONGO_URI"])
app.db=client.panel

app.register_blueprint(auth_bp)
app.run()
